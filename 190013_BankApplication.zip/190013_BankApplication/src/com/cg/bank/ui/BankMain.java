package com.cg.bank.ui;

import java.util.Scanner;

import com.cg.bank.beans.Account;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;
import com.cg.bank.service.BankServiceImpl;

public class BankMain {
	static Scanner sc = new Scanner(System.in);
	private static String input(String string) {
		String message = string;
		System.out.println(message);
		return sc.next();
	}

	private static Account createCustomer() {
		Account account = new Account();
		account.setName(input("enter Name"));
		account.setPhoneNo(Long.parseLong(input("enter Mobile no")));
		account.setMailId(input("enter mailId"));
		account.setAddress(input("enter address"));
		
		return account;
	}
	
	public static void main(String[] args) {
		BankServiceImpl bankServiceImpl = new BankServiceImpl();
		int choice = 0,menu=8;;
		do {
			System.out.println("welcome to Abc Bank");
			System.out.println("1 :Create Account");
			System.out.println("2 :Deposit");
			System.out.println("3 :with draw");
			System.out.println("4 :Funds Transfer");
			System.out.println("Enter Choice: ");
			choice = sc.nextInt();
			

			switch (choice) {
			case 1:
				bankServiceImpl.createAccount(createCustomer());
				System.out.println("Account created Successfully");
				System.out.println("Enter 8 to return to main menu");
				menu=sc.nextInt();
				break;
			case 2:
				try {
					bankServiceImpl.deposit();
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
					
				}
				System.out.println("Enter 8 to return to main menu");
				menu=sc.nextInt();
				break;

			case 3:
				try {
					bankServiceImpl.withdraw();
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
				}
				System.out.println("Enter 8 to return to main menu");
				menu=sc.nextInt();
				break;
			case 4:
				try {
					bankServiceImpl.fundsTransfer();
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
					e.printStackTrace();
				}
				System.out.println("Enter 8 to return to main menu");
				menu=sc.nextInt();
				break;
			
			}
		} while (menu== 8);

	}

	}


