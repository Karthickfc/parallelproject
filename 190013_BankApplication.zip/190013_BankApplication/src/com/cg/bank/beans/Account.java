package com.cg.bank.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="accno",initialValue=1,allocationSize=1)
public class Account {

	@Id
	@GeneratedValue(generator="accno",strategy=GenerationType.SEQUENCE)
	private	int accNo;
	private String Name;
	private long phoneNo;
	private String mailId;
	private String address; 
	private double openingBalance; 
	private	double currentBalance;
	
	
	
	

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public void setName(String name) {
		Name = name;
	}

	

	public int getAccNo() {
		return accNo;
	}

	public String getName() {
		return Name;
	}
	
	public double getOpeningBalance() {
		return openingBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	private void setAccountNo(int accNo) {
		this.accNo = accNo;
	}

	private void setAccountName(String Name) {
		this.Name=Name;
	}

	private void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}
	

	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", Name=" + Name + ", phoneNo=" + phoneNo + ", mailId=" + mailId
				+ ", address=" + address + ", openingBalance=" + openingBalance + ", currentBalance="
				+ currentBalance +  "]";
	}
}
