package com.cg.bank.dao;

import com.cg.bank.beans.Account;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;

public interface BankDao {

	void createAccount(Account account);

	void deposit(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;

	void withdraw(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;
	
	
	
	void fundstransfer(int accno11, int accno12, double currbalance1, double currentbalance2) throws InsufficientBalanceException,AccountNotFoundException;

	String calcQuery(String query) throws AccountNotFoundException;
}
