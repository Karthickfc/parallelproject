package com.cg.bank.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.bank.beans.Account;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;

public class BankDaoImpl implements BankDao {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	Scanner sc = new Scanner(System.in);

	@Override
	public void createAccount(Account account) {
		em.getTransaction().begin();
		em.persist(account);
		em.getTransaction().commit();

	}

	@Override
	public void deposit(int accountno, double amount) throws InsufficientBalanceException, AccountNotFoundException {
		double balance = amount;
		TypedQuery<Account> query = em.createQuery("from Account where accno=:acno", Account.class);
		query.setParameter("acno", accountno);
		Account a = query.getSingleResult();
		if (balance > 0) {
			double currentbalance = a.getOpeningBalance() + balance;
			em.getTransaction().begin();
			a.setCurrentBalance(currentbalance);
			em.getTransaction().commit();
		} else {
			throw new InsufficientBalanceException(accountno, "Enter Valid Amount");
		}

	}

	@Override
	public void withdraw(int accountno, double amount) {

		TypedQuery<Account> query = em.createQuery("from Account where accNo=:accNo", Account.class);
		query.setParameter("accNo", accountno);
		Account a = query.getSingleResult();
		if (amount > 0) {
			double currentbalance = a.getCurrentBalance() - amount;
			em.getTransaction().begin();
			a.setCurrentBalance(currentbalance);
			em.getTransaction().commit();
		} else {
			try {
				throw new InsufficientBalanceException(accountno, "Enter Valid Amount");
			} catch (InsufficientBalanceException e) {
				e.printStackTrace();
			}
		}

	}


	@Override
	public String calcQuery(String query) throws AccountNotFoundException {
		Query query2 = em.createQuery(query);
		String result = String.valueOf(query2.getSingleResult());
		return result;
	}

	@Override

	public void fundstransfer(int accno11, int accno12, double currbalance1, double currentbalance2) {
		TypedQuery<Account> query = em.createQuery("from Account where accno=:p",Account.class);
		query.setParameter("p", accno11);
		Account account =  query.getSingleResult();
		TypedQuery<Account> query2 = em.createQuery("from Account where accno=:g",Account.class);
		query2.setParameter("g", accno12);
		Account account1 = query2.getSingleResult();
		em.getTransaction().begin();
		account.setCurrentBalance(currbalance1);
		account1.setCurrentBalance(currentbalance2);
		em.getTransaction().commit();

	}

}
