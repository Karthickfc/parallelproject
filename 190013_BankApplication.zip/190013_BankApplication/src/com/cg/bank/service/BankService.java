package com.cg.bank.service;

import com.cg.bank.beans.Account;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;

public interface BankService {

	void createAccount(Account account);

	void deposit() throws InsufficientBalanceException, AccountNotFoundException;

	void withdraw() throws InsufficientBalanceException, AccountNotFoundException;
	
	void fundsTransfer() throws InsufficientBalanceException,AccountNotFoundException;
	
	

}
