package com.cg.bank.service;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Transaction {
	@Id
	@GeneratedValue
	private int transactionId;
	private String transDescription;
	private double amount;
	

}
