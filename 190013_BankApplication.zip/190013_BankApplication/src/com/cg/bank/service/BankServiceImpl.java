package com.cg.bank.service;

import java.util.Scanner;

import com.cg.bank.beans.Account;
import com.cg.bank.dao.BankDaoImpl;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;

public class BankServiceImpl implements BankService {

	static Scanner sc = new Scanner(System.in);
	BankDaoImpl bankDaoImpl = new BankDaoImpl();

	@Override
	public void createAccount(Account account) {
		bankDaoImpl.createAccount(account);
	}

	@Override
	public void deposit() throws InsufficientBalanceException, AccountNotFoundException {
		System.out.println("enter Account no to deposit");
		int accountno = sc.nextInt();
		System.out.println("Enter Amount to deposit");
		double amount = sc.nextDouble();
		String query = "select accNo from Account where accNo=" + accountno;
		int accno = Integer.parseInt(bankDaoImpl.calcQuery(query));
		if (accno == accountno) {
			bankDaoImpl.deposit(accountno, amount);
			System.out.println("Deposited Successfully");
		} else {
			throw new AccountNotFoundException(accno, "Account not Found");

		}

	}

	public java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Override
	public void withdraw() throws InsufficientBalanceException, AccountNotFoundException {
		System.out.println("enter Account no to withdraw");
		int accountno = sc.nextInt();
		System.out.println("Enter Amount to Withdraw");
		double amount = sc.nextDouble();
		String query = "select accNo from Account where accNo=" + accountno;
		int accNo = Integer.parseInt(bankDaoImpl.calcQuery(query));
		if (accNo == accountno) {

			String query3 = "select currentBalance from Account where accNo=" + accountno;
			double initbal1 = Double.parseDouble(bankDaoImpl.calcQuery(query3));
			if (initbal1 < amount) {
				throw new InsufficientBalanceException(accountno, "Amount greater than bank balance");
			} else {
				bankDaoImpl.withdraw(accountno, amount);

				System.out.println("withdrawn Successfully");
			}
		} else {
			throw new AccountNotFoundException(accNo, "Account not Found");
		}

	}

	public void fundsTransfer() throws InsufficientBalanceException, AccountNotFoundException {
		System.out.println("enter Sender Account no");
		int accno1 = sc.nextInt();
		System.out.println("Enter Receiver's  account no");
		int accno2 = sc.nextInt();
		String query = "select accNo from Account where accNo=" + accno1;
		int accno11 = Integer.parseInt(bankDaoImpl.calcQuery(query));
		String query1 = "select accNo from Account where accNo=" + accno2;
		int accno12 = Integer.parseInt(bankDaoImpl.calcQuery(query1));
		if (accno1 != accno11) {
			throw new AccountNotFoundException(accno12, "Enter Valid Sender Account no");
		} else if (accno2 != accno12) {
			throw new AccountNotFoundException(accno12, "Enter Valid Receiver's Account no");
		} else {
			System.out.println("Enter amount to be Transfered");
			double amount = sc.nextDouble();
			String query3 = "select currentBalance from Account where accNo=" + accno11;
			double initbal1 = Double.parseDouble(bankDaoImpl.calcQuery(query3));
			System.out.println(initbal1 + "=initbal1");
			String query4 = "select currentBalance from Account where accNo=" + accno12;
			double initbal2 = Double.parseDouble(bankDaoImpl.calcQuery(query4));
			System.out.println(initbal2 + "=initbal2");
			if (initbal1 < amount) {
				throw new InsufficientBalanceException(accno1, "transfer amount lessthan initial balance");
			} else {
				double currbalance1 = initbal1 - amount;
				double currentbalance2 = initbal2 + amount;
				bankDaoImpl.fundstransfer(accno11, accno12, currbalance1, currentbalance2);
				System.out.println("Transfer successfull");
			}
		}

	}

	
}
