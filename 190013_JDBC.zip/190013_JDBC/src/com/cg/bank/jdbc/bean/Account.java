package com.cg.bank.jdbc.bean;

import java.util.ArrayList;

import com.cg.bank.jdbc.service.Transaction;

public class Account {

		
		private	int accNo;
		private String Name;
		private long phoneNo;
		private String mailId;
		private String address; 
		private double openingBalance; 
		private	double currentBalance=0;
		ArrayList<Transaction> arrayList;
		
		

		public long getPhoneNo() {
			return phoneNo;
		}

		public void setPhoneNo(long phoneNo) {
			this.phoneNo = phoneNo;
		}

		public String getMailId() {
			return mailId;
		}

		public void setMailId(String mailId) {
			this.mailId = mailId;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public void setAccNo(int accNo) {
			this.accNo = accNo;
		}

		public void setName(String name) {
			Name = name;
		}

		
		public Account(String Name, double openingBalance,long phoneNo,String mail,String address) {
			super();
			
			setAccountName(Name);
			setOpeningBalance(openingBalance);
			setCurrentBalance(openingBalance);
			setPhoneNo(phoneNo);
			setMailId(mail);
			setAddress(address);
			this.arrayList = new ArrayList<Transaction>();
			
		}
		
		public Account(){
			super();
			this.arrayList=new ArrayList<Transaction>();
		}

		public ArrayList<Transaction> getArrayList() {
			return arrayList;
		}

		public void setArrayList(ArrayList<Transaction> arrayList) {
			this.arrayList = arrayList;
		}

		public int getAccNo() {
			return accNo;
		}

		public String getName() {
			return Name;
		}
		
		public double getOpeningBalance() {
			return openingBalance;
		}

		public double getCurrentBalance() {
			return currentBalance;
		}

		private void setAccountNo(int accNo) {
			this.accNo = accNo;
		}

		private void setAccountName(String Name) {
			this.Name=Name;
		}

		private void setOpeningBalance(double openingBalance) {
			this.openingBalance = openingBalance;
		}

		public void setCurrentBalance(double currentBalance) {
			this.currentBalance = currentBalance;
		}
		
		public void transactiondetails(Transaction trans) {
			this.arrayList.add(trans);
		}

		@Override
		public String toString() {
			return "Account [accNo=" + accNo + ", Name=" + Name + ", phoneNo=" + phoneNo + ", mailId=" + mailId
					+ ", address=" + address + ", openingBalance=" + openingBalance + ", currentBalance="
					+ currentBalance + ", arrayList=" + arrayList + "]";
		}
		
	}



