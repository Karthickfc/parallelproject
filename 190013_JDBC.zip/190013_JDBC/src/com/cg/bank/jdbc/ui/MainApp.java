package com.cg.bank.jdbc.ui;

import java.util.Collection;
import java.util.Scanner;

import com.cg.bank.jdbc.bean.Account;
import com.cg.bank.jdbc.dao.AccountDao;
import com.cg.bank.jdbc.dao.AccountDaoImpl;
import com.cg.bank.jdbc.exception.AccountNotFoundException;
import com.cg.bank.jdbc.exception.InsufficientBalanceException;
import com.cg.bank.jdbc.service.AccountService;
import com.cg.bank.jdbc.service.AccountServiceImpl;

public class MainApp {

		static Scanner sc = new Scanner(System.in);

		public static Account getInputAccount() {
			String Name = getInput("Enter Name:");
			String bal = getInput("Enter Opening Balance:");
			double openingBalance = Double.parseDouble(bal);
			String ph= getInput("Enter your phone no");
			long phoneNo = Long.parseLong(ph);
			String mail= getInput("Enter your MailId");
			String address= getInput("Enter your Address");
			Account account = new Account(Name, openingBalance,phoneNo,mail,address);
			return account;
		}

		public static String getInput(String message) {
			System.out.println(message);
			return sc.next();
		}

		public static void main(String[] args) {
			AccountService accountService = new AccountServiceImpl() ;
			Account account;
			AccountDao accountDao = new AccountDaoImpl();
			int choice = 0;
			Integer accountNo;
			double amount;
			int back=0;
			do {
				System.out.println("Welcome to ABC Bank...");
				System.out.println("1.Create Account");
				System.out.println("2.Deposit");
				System.out.println("3.Withdraw");
				System.out.println("4.FundsTransfer");
				System.out.println("5.Delete");
				System.out.print("Enter Choice:");
				choice = sc.nextInt();

				switch (choice) {
				case 1:
					account = getInputAccount();
					accountService.createAccount(account);
					System.out.println("Your ABC account is successfully created.");
					System.out.println("Enter 8 to Return.");
				     back=sc.nextInt();
					break;
				case 2:
					System.out.println("enter Accountno");
					accountNo =sc.nextInt();
					System.out.println("Enter Amount");
					amount = sc.nextDouble();
					try {
						accountService.deposit(accountNo, amount);
					} catch (AccountNotFoundException e) {
						System.out.println("Amount Deposit cancelled ");
					}
					System.out.println("Amount Deposited.");
					System.out.println("Enter 8 to Return.");
				     back=sc.nextInt();
					break;
				case 3:
					accountNo = Integer.parseInt(getInput("\nEnter Account No: "));
					amount = Double.parseDouble(getInput("\nEnter Amount: "));
					try {
						accountService.withdraw(accountNo, amount);
					} catch (AccountNotFoundException | InsufficientBalanceException e) {
						System.out.println("Amount Withdrawn cancelled ");
					}
					System.out.println("Account Withdrawn.");
					System.out.println("Enter 8 to Return.");
				     back=sc.nextInt();
					break;
				case 4:
					Integer accountNoSource = Integer.parseInt(getInput("\nEnter Source Account No: "));
					Integer accountNoTarget = Integer.parseInt(getInput("\nEnter Target Account No: "));
					try {
						accountService.fundsTransfer(accountNoSource, accountNoTarget);
						System.out.println("Fund Transfer ended.");
					} catch (AccountNotFoundException e) {
						System.out.println("Fund Transfer cancelled ");
					} catch (InsufficientBalanceException e) {
						System.out.println("Fund Transfer cancelled ");
					}
					break;
				case 5:
					
					accountNo = Integer.parseInt(getInput("\nEnter Account No: "));
					try {
						accountDao.delete(accountNo);
						throw new AccountNotFoundException("Account no "+accountNo + " not found" );
					} catch (AccountNotFoundException e) {
						e.printStackTrace();
					}
					System.out.println("Enter 8 to Return.");
				     back=sc.nextInt();
					break;
				
				default:
					System.out.println("Exit.");
				}
			} while(back== 8);
		}
	}





