package com.cg.bank.jdbc.service;

public class Transaction {

	static Integer TRANSACTION_ID_SEQUENCE = 4554545;
	private Integer transactionId;
	private String description;
	private double amount;

	public Transaction() {
		super();
		this.setTransactionId(TRANSACTION_ID_SEQUENCE);
	}

	public Transaction(String description, double amount) {
		super();
		this.setTransactionId(TRANSACTION_ID_SEQUENCE);
		this.setDescription(description);
		this.setAmount(amount);
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int TRANSACTION_ID_SEQUENCE) {
		this.transactionId = TRANSACTION_ID_SEQUENCE++;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", description=" + description + ", amount="
				+ amount + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(amount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((transactionId == null) ? 0 : transactionId.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (Double.doubleToLongBits(amount) != Double.doubleToLongBits(other.amount))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (transactionId == null) {
			if (other.transactionId != null)
				return false;
		} else if (!transactionId.equals(other.transactionId))
			return false;
		return true;
	}

	
	
	
}
