package com.cg.bank.jdbc.service;


import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.bank.jdbc.bean.Account;
import com.cg.bank.jdbc.dao.AccountDao;
import com.cg.bank.jdbc.dao.AccountDaoImpl;
import com.cg.bank.jdbc.exception.AccountNotFoundException;
import com.cg.bank.jdbc.exception.InsufficientBalanceException;

public class AccountServiceImpl implements AccountService {

	static Scanner sc = new Scanner(System.in);
	AccountDaoImpl accountDao = new AccountDaoImpl();
	
	
	

	@Override
	public void createAccount(Account account) {
		accountDao.insert(account);
		
	}

	@Override
	public void deposit(Integer accountNo, double amount) throws AccountNotFoundException {
		String string = "select accNo from Account where accNo=" + accountNo;
		Integer accountNo1= Integer.parseInt(accountDao.query(string));
		double currentBalance=0;
		if(accountNo1.equals(accountNo))
		{
			String str = "select accNo from Account where accNo=" + accountNo;
			double openinglBalance= Integer.parseInt(accountDao.query(str));
			
			currentBalance +=amount + openinglBalance;
			accountDao.update(currentBalance, accountNo);
		    Transaction trans = new Transaction("Deposited", amount);
			System.out.println("");
			
			java.sql.Date date = getCurrentDate();
			accountDao.transactionDetails(trans, accountNo, date);
			
		}
		else
		{
			try{
			throw new AccountNotFoundException(accountNo + " does not exists.");
			
		}catch(AccountNotFoundException e){
			
		}
		}
		
	}
	public java.sql.Date getCurrentDate(){
		java.util.Date currentDate = new java.util.Date();
		return new java.sql.Date(currentDate.getTime());
	}

	@Override
	public void withdraw(Integer accountNo, double amount) throws AccountNotFoundException, InsufficientBalanceException {
		
		String string = "select accNo from Account where accNo=" + accountNo;
		Integer accountNo1= Integer.parseInt(accountDao.query(string));
		double currentBalance=0;
		if(accountNo1.equals(accountNo))
		{
			String str = "select currentBalance from Account where accNo=" + accountNo;
			double currentlBalance= Integer.parseInt(accountDao.query(str));
			if(currentlBalance>= amount){
			currentBalance +=currentlBalance -amount;
			accountDao.update(currentBalance, accountNo);
		    Transaction trans = new Transaction("Deposited", amount);
			System.out.println("");
			
			java.sql.Date date = getCurrentDate();
			accountDao.transactionDetails(trans, accountNo, date);
			
		
	}
		}
		}

	@Override
	public void fundsTransfer(Integer accountNoSource, Integer accountNoTarget)
			throws AccountNotFoundException, InsufficientBalanceException {
		double sourceAmt = 0, targetAmt = 0, amount = 0;
		if(accountNoSource.equals(accountNoTarget)) 
			{
			throw new AccountNotFoundException(accountNoSource+ accountNoTarget +" are same.");
			}
		String string1 = "select currentBalance from Account where accNo=" + accountNoSource;
		double curr1 = Integer.parseInt(accountDao.query(string1));
		String string2 = "select currentBalance from Account where accNo=" + accountNoTarget;
		double curr2 = Integer.parseInt(accountDao.query(string2));
		System.out.println("Enter amount to be transfered");
		amount = sc.nextDouble();
		
		
		
		if (amount > curr1) {
			throw new InsufficientBalanceException("Account no  "+accountNoSource + " has insufficient balance");
		} else {
			targetAmt = curr2 + amount;
			sourceAmt = curr1 - amount;

			System.out.println("fund transfered successfully");

			accountDao.update(sourceAmt, accountNoSource);
			accountDao.update(targetAmt, accountNoTarget);
			Transaction transaction1 = new Transaction( "Deposited", amount);

			java.sql.Date date1 = getCurrentDate();
			accountDao.transactionDetails(transaction1, accountNoSource, date1);
			Transaction transaction = new Transaction("Deposited", amount);

			java.sql.Date date2 = getCurrentDate();
			accountDao.transactionDetails(transaction, accountNoTarget, date2);
		}
	}

	

		
	}


	

	



	


	


