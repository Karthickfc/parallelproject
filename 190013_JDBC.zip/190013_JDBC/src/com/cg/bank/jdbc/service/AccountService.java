package com.cg.bank.jdbc.service;

import java.util.Collection;

import com.cg.bank.jdbc.bean.Account;
import com.cg.bank.jdbc.exception.AccountNotFoundException;
import com.cg.bank.jdbc.exception.InsufficientBalanceException;


public interface AccountService {
	 void createAccount(Account account);
	 void withdraw(Integer accountNo, double amount) throws AccountNotFoundException, InsufficientBalanceException;
	// void fundsTransfer(Integer accountNoSource, Integer accountNoTarget) throws AccountNotFoundException, InsufficientBalanceException;
	void fundsTransfer(Integer accountNoSource, Integer accountNoTarget)
			throws AccountNotFoundException, InsufficientBalanceException;
	void deposit(Integer accountNo, double amount) throws AccountNotFoundException;
	
	

}
