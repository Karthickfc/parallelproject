package com.cg.bank.jdbc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.bank.jdbc.bean.Account;
import com.cg.bank.jdbc.exception.AccountNotFoundException;
import com.cg.bank.jdbc.service.Transaction;

public class AccountDaoImpl implements AccountDao{
 
	Scanner scanner = new Scanner(System.in);
	@Override
	public void insert(Account account) {
		try{
			Connection connection = DatabaseUtility.getConnection();
			PreparedStatement statement = connection.prepareStatement("insert into Account (accNo,Name,phoneNo,mailId,address,openingBalance,currentBalance) values (accno.nextval,?,?,?,?,?,?)",new String[]{"accno"});
			statement.setString(1, account.getName());
			statement.setLong(2, account.getPhoneNo());
			statement.setString(3, account.getMailId());
			statement.setString(4, account.getAddress());
			statement.setDouble(5, account.getOpeningBalance());
			statement.setDouble(6, account.getCurrentBalance());
			
			int index = statement.executeUpdate();
			
			ResultSet resultSet = statement.getGeneratedKeys();
			resultSet.next();
			
			account.setAccNo((int) resultSet.getLong(1));
			if(index>0){
				System.out.println("");
			}
			
			
			
			
		}catch (SQLException ex){
			ex.printStackTrace();
		}
		
	}

	@Override
	public void update(double balanceAmount, Integer accountNo) {
		String string = "update Account set currentBalance = "+ balanceAmount + "where accNo=" + accountNo;
		
		try{
               Connection connection = DatabaseUtility.getConnection(); 
				Statement statement = connection.createStatement(); 

				int index = statement.executeUpdate(string);
				if (index > 0)
					System.out.println("");

			} catch (SQLException e) {
				
			}
			
		}
		
	

	@Override
	public void delete(Integer accountNo) throws AccountNotFoundException {
		String string = "delete from Account where accNo=" + accountNo;

		try  {
			Connection connection = DatabaseUtility.getConnection();
			Statement st = connection.createStatement();

			int index = st.executeUpdate(string);
			if (index > 0)
				System.out.println("row deleted");
			else {
				throw new AccountNotFoundException("Account No "+accountNo + "not found");
			}

		} catch (SQLException e) {
			
		}

		
	}

	@Override
	public void transactionDetails(Transaction trans, Integer accountNo, Date date) {
		try {
			Connection connection = DatabaseUtility.getConnection();
					PreparedStatement statement = connection.prepareStatement(
							"insert into TRANSACTION  values (?,TRANS_ID.nextval,?,?,?)", new String[] { "TRANS_ID" }); 

					statement.setInt(1, accountNo);
					statement.setString(2, trans.getDescription());
					statement.setDouble(3, trans.getAmount());
					statement.setDate(4, date);
				int index = statement.executeUpdate();
				ResultSet set = statement.getGeneratedKeys();
				set.next();
				trans.setTransactionId((int) set.getLong(1));

				if (index > 0)
					System.out.println("");

			} catch (SQLException e) {
				
			}
		
	}

	@Override
	public void query() {
		String string = scanner.nextLine();

		try{
			Connection connection = DatabaseUtility.getConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(string); 

			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int count = resultSetMetaData.getColumnCount();
			if (count == 0) {
				System.err.println("deleted all rows");
			}
			else{
			while (resultSet.next()) {
				for (int index = 1; index <= count; index++) {
					System.out.print(resultSet.getString(index) + " ");
				}
				System.out.println();
			}
			}
		} catch (SQLException e) {
			
		}

	}

	public String query(String query) {
		String result = null;
		try  {
			Connection connection = DatabaseUtility.getConnection();
				
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(query);
			while (resultSet.next()) {
				result = resultSet.getString(1);
			}
		} catch (SQLException e) {
			
		}
		return result;
	}

	
}
