package com.cg.bank.service;

import java.util.Collection;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;

public interface AccountService {
	public int createAccount(Account account);
	public void deposit(int accountNo, double amount) throws AccountNotFoundException;
	public void withdraw(int accountNo, double amount) throws AccountNotFoundException, InsufficientBalanceException;
	public void fundsTransfer(int accountNoSource, int accountNoTarget, double amount) throws AccountNotFoundException, InsufficientBalanceException;
	public double getBalance(int accountNo) throws AccountNotFoundException;
	public void getTransactions(int accountNo) throws AccountNotFoundException;

}
