package com.cg.bank.service;


import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;

public class AccountServiceImpl implements AccountService {

	Map<Integer, Account> hashMap;
	public AccountServiceImpl(){
		hashMap= new HashMap<>();
	}
	

	@Override
	public int createAccount(Account account) {
		hashMap.put(account.getAccNo(), account);
		return account.getAccNo();
	}

	@Override
	public void deposit(int accountNo, double amount) throws AccountNotFoundException {
		Account account = hashMap.get(accountNo);
		if(account==null)
		{
			throw new AccountNotFoundException(accountNo + " does not exists.");
			
		}
		else
		{
			double currentBalance= account.getCurrentBalance();
			currentBalance +=amount;
			account.setCurrentBalance(currentBalance);
			Transaction trans = new Transaction("Deposited", amount);
			hashMap.get(accountNo).transactiondetails(trans);
			System.out.println("Deposited Successfully");
			
		}
		
	}

	@Override
	public void withdraw(int accountNo, double amount) throws AccountNotFoundException, InsufficientBalanceException {
		Account account = hashMap.get(accountNo);
		if(account == null) 
			{
			throw new AccountNotFoundException(accountNo+" does not exists.");
			}
		else{
		
		double currentBalance = account.getCurrentBalance();
		if(currentBalance <= amount) 
			{
			throw new InsufficientBalanceException("Your account no "+accountNo+" has insufficient balance.");
			}
		currentBalance -= amount;
		account.setCurrentBalance(currentBalance);
		Transaction trans =  new Transaction("Withdrawn",amount);
		System.out.println("Withdrawn Successfully");
		}
		
	}

	@Override
	public void fundsTransfer(int accountNoSource, int accountNoTarget, double amount)
			throws AccountNotFoundException, InsufficientBalanceException {
		Account sourceAccount = hashMap.get(accountNoSource);
		if(sourceAccount == null) 
			{
			throw new AccountNotFoundException(sourceAccount+" does not exists.");
			}
		
		Account targetAccount = hashMap.get(accountNoTarget);
		if(targetAccount == null)
		{
			throw new AccountNotFoundException(accountNoTarget+" does not exists.");
		}

		System.out.println("Account Source:"+ accountNoSource);
		System.out.println("Account Target  :"+ accountNoTarget);
		
		double accountSourceBalance =  sourceAccount.getCurrentBalance();
		if(accountSourceBalance <= amount) throw new InsufficientBalanceException("Your account no "+ accountNoSource+" has insufficient balance.");
		
		accountSourceBalance -= amount;
		sourceAccount.setCurrentBalance(accountSourceBalance);
		Transaction trans1 = new Transaction("Debitted",amount);
		double accountTargetBalance = targetAccount.getCurrentBalance();
		accountTargetBalance += amount;
		
		
		targetAccount.setCurrentBalance(accountTargetBalance);
		Transaction trans2 = new Transaction("Credited",amount);
		
		System.out.println("Account From:"+ accountNoSource);
		System.out.println("Account To  :"+ accountNoTarget);
		System.out.println("fund transfered Successfully");

		
	}

	@Override
	public double getBalance(int accountNo) throws AccountNotFoundException {
		Account account = hashMap.get(accountNo);
		if(account == null) 
			{
			throw new AccountNotFoundException(accountNo+" does not exists.");
			}
		return hashMap.get(accountNo).getCurrentBalance();
	}

	@Override
	public void getTransactions(int accountNo) throws AccountNotFoundException {
		if(hashMap.containsKey(accountNo)){
			List<Transaction> transaction= hashMap.get(accountNo).getArrayList();
			transaction.forEach(System.out::println);
		}
		else{
			throw new AccountNotFoundException("Account not found ");
		}
		
	}

}
